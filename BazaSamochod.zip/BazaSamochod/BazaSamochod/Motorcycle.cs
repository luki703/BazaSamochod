﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BazaSamochod
{
    class Motorcycle : Vechicle
    {
        public Motorcycle(string numberId, 
                          string brand, 
                          string model, 
                          int yearOfProduction, 
                          Condition condition, 
                          string color)
        { }
    }
}
