﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;
using System.Collections;

namespace BazaSamochod
{
    public partial class MainWindow : Window
    {
        private Car ncar;
        private Motorcycle nbike;
        private Truck ntruck;
        private Vechicle nvec;
        List<Vechicle> iList = new List<Vechicle>();
        List<string> FileLineList = new List<string>();
        string[] tmp = new string[8];
        string EndingMark = "+-+++";
        public MainWindow()
        {
            InitializeComponent();
            OpenFile();
        }
        private void SelectVechicle()
        {

            VechicleForm.DataContext = ListView1.SelectedItem;
        }
        private void ClearForm()
        {
            TextBox0.Clear();
            TextBox1.Clear();
            TextBox2.Clear();
            TextBox3.Clear();
            ComboBox1.SelectedIndex = 0;
            ComboBox2.SelectedIndex = 0;

        }
        private void SaveToFile()
        {
            if (!Directory.Exists(@"\fileData"))
            { Directory.CreateDirectory(@"\fileData"); }
            string index = Guid.NewGuid().ToString();

            try
            {
                Condition state = (Condition)Enum.Parse(typeof(Condition), ComboBox1.SelectedValue.ToString());

                if (ComboBox2.SelectedValue.ToString() == Type.Samochód_Osobowy.ToString())
                {
                    ncar = new Car(index, TextBox0.Text, TextBox1.Text, int.Parse(TextBox2.Text), state, TextBox3.Text);
                }
                else if (ComboBox2.SelectedValue.ToString() == Type.Motocykl.ToString())
                {
                    nbike = new Motorcycle(index, TextBox0.Text, TextBox1.Text, int.Parse(TextBox2.Text), state, TextBox3.Text);
               }
                else if (ComboBox2.SelectedValue.ToString() == Type.Ciężarówka.ToString())
                {
                    ntruck = new Truck(index,
                                       TextBox0.Text,
                                       TextBox1.Text,
                                       int.Parse(TextBox2.Text),
                                       state,
                                       TextBox3.Text);
                }
                StreamWriter file = new StreamWriter(@"\fileData\text.txt", true);
                file.WriteLine(index);//numerId-0
                file.WriteLine(ComboBox2.SelectedValue);//rodzaj pojazdu-1
                file.WriteLine(TextBox0.Text);//marka-2
                file.WriteLine(TextBox1.Text);//model-3
                file.WriteLine(TextBox2.Text);//rok produkcji-4
                file.WriteLine(TextBox3.Text);//kolor-5
                file.WriteLine(ComboBox1.SelectedValue.ToString());//stan-6
                file.WriteLine(EndingMark);//end-7
                file.Close();
                ListView1.Items.Add(nvec = new Vechicle(
                    (Type)Enum.Parse(typeof(Type), ComboBox2.SelectedValue.ToString()),
                    TextBox0.Text,
                    TextBox1.Text,
                    int.Parse(TextBox2.Text),
                    TextBox3.Text,
                    (Condition)Enum.Parse(typeof(Condition), ComboBox1.SelectedValue.ToString())));
                iList.Add(nvec);
                MessageBox.Show("Zapisano do pliku", "Zapisano", 
                                MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch(FormatException)
            {
                MessageBox.Show("Prosze wprowadzić poprawne dane");
            }
            catch(NullReferenceException)
            {
                MessageBox.Show("Prosze wprowadzić dane");
            }
        }

        private void OpenFile()
        {
            if (File.Exists(@"\fileData\text.txt"))
            {

                using (StreamReader reader = new StreamReader(@"\fileData\text.txt"))
                {
                    while (true)
                    {

                        for (int i = 0; i <= tmp.Length; i++)
                        {
                            tmp[i] = reader.ReadLine();

                            if (i == 7)
                            { break; }
                        }
                        if (tmp[7] == EndingMark & tmp[7] != null)

                        {if ((Type)Enum.Parse(typeof(Type), tmp[1]) == Type.Samochód_Osobowy)
                            {ncar = new Car(tmp[0], 
                                            tmp[2], 
                                            tmp[3], 
                                            int.Parse(tmp[4]), 
                                            (Condition)Enum.Parse(typeof(Condition), tmp[6]), 
                                            tmp[5]); }
                            else if ((Type)Enum.Parse(typeof(Type), tmp[1]) == Type.Motocykl)
                            { nbike = new Motorcycle(tmp[0], 
                                                     tmp[2], 
                                                     tmp[3], 
                                                     int.Parse(tmp[4]), 
                                                     (Condition)Enum.Parse(typeof(Condition), 
                                                     tmp[6]), 
                                                     tmp[5]); }
                            else if ((Type)Enum.Parse(typeof(Type), tmp[1]) == Type.Ciężarówka)
                            { ntruck = new Truck(tmp[0], 
                                                 tmp[2], 
                                                 tmp[3], 
                                                 int.Parse(tmp[4]), 
                                                 (Condition)Enum.Parse(typeof(Condition), 
                                                 tmp[6]), 
                                                 tmp[5]); }
                            else { }
                            nvec = new Vechicle((Type)Enum.Parse(typeof(Type), tmp[1]), 
                                                tmp[2], 
                                                tmp[3], 
                                                int.Parse(tmp[4]), 
                                                tmp[5], 
                                                (Condition)Enum.Parse(typeof(Condition), tmp[6]));
                            iList.Add(nvec);
                        }
                        else { break; }
                    }
                    FulfillListView();
                }
            }
            else { }
        }
        private void FulfillListView()
        {
            foreach (object obj in iList)
            { ListView1.Items.Add(obj); }
        }
        private void Button0_Click(object sender, RoutedEventArgs e)
        { SaveQuestion(); }
        private void SaveQuestion()
        {
            MessageBoxResult result = MessageBox.Show("Zapisać zmiany?", "Uwaga", 
                                      MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            switch (result)
            {
                case MessageBoxResult.Yes:
                    SaveToFile();
                    break;
                case MessageBoxResult.No:
                    break;
                case MessageBoxResult.Cancel:
                    break;
            }
        }
        private void menuNew_Click(object sender, RoutedEventArgs e)
        {
            SaveQuestion();
            ClearForm();
        }
        private void menuSave_Click(object sender, RoutedEventArgs e)
        {
            SaveToFile();
        }
        private void RewriteWholeFile()
        {
            string[] lines = File.ReadAllLines(@"\fileData\text.txt", Encoding.UTF8);
            List<string> HelpingList = new List<string>(lines);
            int counter = -1;
            int k=0;
            for (int i = 0; i < lines.Length; i++)
            {
                if (counter.Equals(int.Parse(ListView1.SelectedIndex.ToString())))
                {
                    ListView1.Items.Remove(ListView1.SelectedItem);
                    if (counter != 0)
                    {
                        k = 7 * counter;
                    }
                    else { }
                    HelpingList.RemoveRange(k-1, 8);
                    File.Delete(@"\fileData\text.txt");
                    StreamWriter file = new StreamWriter(@"\fileData\text.txt", true);
                    foreach (string str in HelpingList)
                    { file.WriteLine(str); }
                    file.Close();
                    break;
                }
                
                if (lines[i] == EndingMark)
                {
                    counter++;
                }
            }
            }
        private void menuDelete_Click(object sender, RoutedEventArgs e)
        {
            RewriteWholeFile();
        }
        private void exit(object sender, RoutedEventArgs e)
        {
            SaveQuestion();
            Environment.Exit(1);
        }
        private void ItemList_Checked(object sender, RoutedEventArgs e)
        {
            FulfillListView();
        }
        private void ItemList_UnChecked(object sender, RoutedEventArgs e)
        {
            ListView1.Items.Clear();
        }
        private void ListView1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectVechicle();
        }
    }
}
