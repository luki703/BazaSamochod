﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BazaSamochod
{
   class Car : Vechicle
    {             
        public Car(string numberId, 
                   string brand, 
                   string model, 
                   int yearOfProduction, 
                   Condition condition, 
                   string color)
        { }
        
    }
}
